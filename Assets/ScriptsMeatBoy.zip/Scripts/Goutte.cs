﻿using UnityEngine;

public class Goutte : MonoBehaviour
{
    [SerializeField] Vector3 velocity;
    [SerializeField] float force;

    void Start()
    {
        GetComponent<Rigidbody>().AddForce(velocity * force);
    }

    void Update()
    {

    }

    private void OnCollisionEnter(Collision other)
    {
        Destroy(GetComponent<Rigidbody>());
        Invoke("DestroyObject",2f);
        //Destroy(this);
    }

    public void SetVelocity(Vector3 newVelocity){
        velocity = newVelocity;
    }

    public Vector3 GetVelocity() {
        return velocity;
    }

    void DestroyObject() =>Destroy(gameObject);
    


}
