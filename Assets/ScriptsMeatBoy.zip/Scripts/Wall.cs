﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wall : MonoBehaviour
{
    private void OnCollisionEnter(Collision other)
    {
        Debug.Log("Collision");
        if (other.gameObject.tag == "Player")
        {
            if (other.gameObject.GetComponent<MeatBoy>().GetLastWallJumped() != this)
            {
                other.gameObject.GetComponent<MeatBoy>().AddJumpWallCount(1);
                other.gameObject.GetComponent<MeatBoy>().SetLastWallJumped(this);
            }
        }
    }

    private void OnCollisionExit(Collision other)
    {
        if (other.gameObject.tag == "Player")
        {
            Debug.Log("Exit");
        }
    }
}
