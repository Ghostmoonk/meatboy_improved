﻿using UnityEngine;

public class MeatBoy : Character
{
    #region Mouvements
    [SerializeField] float speed;

    #region Sauts
    [SerializeField] int jumpsMax = 2;
    int jumpWallCount = 0;
    int jumpsCount;
    #endregion

    #endregion

    #region Prefabs
    [SerializeField] GameObject gouttePrefab;
    [SerializeField] float delayGoutte;
    float cptGoutte;
    #endregion

    #region Respawn
    Vector3 defaultPosition;
    #endregion

    #region WallJump
    Wall lastWallJumped;
    #endregion

    private void Start()
    {
        defaultPosition = transform.position;
    }

    protected override void Update()
    {
        mouvement.x = Input.GetAxis("Horizontal") * speed;
        base.Update();

        if (controller.isGrounded)
        {
            if (jumpWallCount > 0)
                jumpWallCount = 0;

            mouvement.y = 0f;
            if (jumpsCount > 0)
                jumpsCount = 0;
        }

        #region Saut

        if (Input.GetButtonDown("Jump") && jumpsCount < jumpsMax + jumpWallCount)
        {
            mouvement.y = jumpSpeed;
            jumpsCount++;
        }

        #endregion

        controller.Move(mouvement * Time.deltaTime);

        if (mouvement.x != 0f)
        {
            cptGoutte -= Time.deltaTime;
        }

        if (cptGoutte < 0)
        {
            Goutte goutteInstance = Instantiate(gouttePrefab, transform.position, Quaternion.identity).GetComponent<Goutte>();
            goutteInstance.SetVelocity(new Vector3(goutteInstance.GetVelocity().x - mouvement.x, goutteInstance.GetVelocity().y, goutteInstance.GetVelocity().z));
            cptGoutte = delayGoutte;
        }
    }

    public void Die()
    {
        controller.enabled = false;
        transform.position = defaultPosition;
        controller.enabled = true;
    }

    public Wall GetLastWallJumped() => lastWallJumped;

    public void SetLastWallJumped(Wall wall) => lastWallJumped = wall;

    public void AddJumpWallCount(int amount) => jumpWallCount += amount;

}